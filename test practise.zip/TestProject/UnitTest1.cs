using test_practise.Data;
using test_practise.Controllers;
using Microsoft.EntityFrameworkCore;
using test_practise;

namespace TestProject
{
    public class Tests
    {
        Controller1 Controller1 { get; set; }

        [SetUp]
        public void Setup()
        {
            Context Context;
            var options = new DbContextOptionsBuilder<Context>().UseInMemoryDatabase(databaseName: "Example").Options;

            Context = new Context(options);
            Context.Database.EnsureDeleted();
            Context.Database.EnsureCreated();

            object1 obj = new object1{ Id = 1, Name = "Ivan", Description = "Just a random gay", object2s = new List<object2>() };
            Context.Object1s.Add(obj);
            Context.SaveChanges();

            Controller1 = new Controller1(Context);
        }

        [Test]
        public void GetAllReturns()
        {
            var result = Controller1.GetAll();
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual("Ivan", result[0].Name);
        }
    }
}