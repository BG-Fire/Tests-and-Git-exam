﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_practise.Data
{
    public class Context : DbContext
    {
        public DbSet<object1> Object1s { get; set; }
        public DbSet<object2> Object2s { get; set; }

        public Context() { }
        public Context(DbContextOptions options) : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server = myServerAddress; Database = myDataBase; Trusted_Connection = True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<object1>();
            modelBuilder.Entity<object2>().HasMany<object1>();
        }
    }
}
