﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test_practise.Data;

namespace test_practise.Controllers
{
    public class Controller1
    {
        Context context;

        public Controller1(Context context)
        {
            this.context = context;
        }

        public List<object1> GetAll()
        {
            return context.Object1s.ToList();
        }

        public object1 GetObject(int id)
        {
            return context.Object1s.Find(id);
        }

        public void Create(object1 obj)
        {
            if (obj != null)
            {
                context.Object1s.Add(obj);
                context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            object1 obj = context.Object1s.Find(id);
            if (obj != null)
            {
                context.Object1s.Remove(obj);
            }
        }

        public void Update(object1 obj)
        {
            object1 curr = context.Object1s.Find(obj.Id);
            if (curr != null)
            {
                context.Entry(curr).CurrentValues.SetValues(obj);
            }
        }
    }
}
